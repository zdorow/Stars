/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package star;

/*
Programmer: Zachary Dorow
Programming Project 4.6
Object Oriented Programming I
Box Excercise 
 */
public class Polygon {

}
